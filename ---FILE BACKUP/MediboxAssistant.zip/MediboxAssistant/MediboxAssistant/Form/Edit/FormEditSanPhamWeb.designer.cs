﻿namespace Medibox
{
    partial class FormEditSanPhamWeb
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUserName = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.txtAPIKey = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtPassword = new DevComponents.DotNetBar.LabelX();
            this.txtLoai = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.textBoxX2 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.mListViewData = new Sanita.Utility.UI.ObjectListView();
            this.olvColumn2 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn17 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn18 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn19 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn20 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn21 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn22 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn23 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn24 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn25 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn26 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn27 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn28 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn29 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn32 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn37 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn38 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn39 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn41 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn42 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.checkBoxAn = new System.Windows.Forms.CheckBox();
            this.checkBoxHienThi = new System.Windows.Forms.CheckBox();
            this.txtHassIO_KEY = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.txtTag = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.txtTenSanPham = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtLongitude = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtAlias = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.txtNhaCungCap = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.panelEx2 = new DevComponents.DotNetBar.PanelEx();
            this.btnSave = new DevComponents.DotNetBar.ButtonX();
            this.panelEx1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mListViewData)).BeginInit();
            this.panelEx2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtUserName
            // 
            // 
            // 
            // 
            this.txtUserName.Border.Class = "TextBoxBorder";
            this.txtUserName.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtUserName.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtUserName.FocusHighlightEnabled = true;
            this.txtUserName.Location = new System.Drawing.Point(1032, 1359);
            this.txtUserName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(420, 27);
            this.txtUserName.TabIndex = 1;
            this.txtUserName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // labelX3
            // 
            this.labelX3.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Location = new System.Drawing.Point(1179, 1284);
            this.labelX3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(130, 27);
            this.labelX3.TabIndex = 20;
            this.labelX3.Text = "Tên người dùng";
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(12, 170);
            this.labelX2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(143, 27);
            this.labelX2.TabIndex = 19;
            this.labelX2.Text = "Trạng thái hiển thị";
            // 
            // txtAPIKey
            // 
            // 
            // 
            // 
            this.txtAPIKey.Border.Class = "TextBoxBorder";
            this.txtAPIKey.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtAPIKey.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtAPIKey.FocusHighlightEnabled = true;
            this.txtAPIKey.Location = new System.Drawing.Point(35, 1284);
            this.txtAPIKey.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAPIKey.Name = "txtAPIKey";
            this.txtAPIKey.Size = new System.Drawing.Size(420, 27);
            this.txtAPIKey.TabIndex = 3;
            this.txtAPIKey.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.txtPassword.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtPassword.Location = new System.Drawing.Point(712, 93);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(130, 27);
            this.txtPassword.TabIndex = 19;
            this.txtPassword.Text = "Loại";
            // 
            // txtLoai
            // 
            // 
            // 
            // 
            this.txtLoai.Border.Class = "TextBoxBorder";
            this.txtLoai.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtLoai.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtLoai.FocusHighlightEnabled = true;
            this.txtLoai.Location = new System.Drawing.Point(889, 95);
            this.txtLoai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLoai.Name = "txtLoai";
            this.txtLoai.Size = new System.Drawing.Size(420, 27);
            this.txtLoai.TabIndex = 5;
            this.txtLoai.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // panelEx1
            // 
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.panelEx1.Controls.Add(this.textBoxX2);
            this.panelEx1.Controls.Add(this.textBoxX1);
            this.panelEx1.Controls.Add(this.labelX9);
            this.panelEx1.Controls.Add(this.mListViewData);
            this.panelEx1.Controls.Add(this.checkBoxAn);
            this.panelEx1.Controls.Add(this.checkBoxHienThi);
            this.panelEx1.Controls.Add(this.txtHassIO_KEY);
            this.panelEx1.Controls.Add(this.labelX8);
            this.panelEx1.Controls.Add(this.txtTag);
            this.panelEx1.Controls.Add(this.labelX7);
            this.panelEx1.Controls.Add(this.txtTenSanPham);
            this.panelEx1.Controls.Add(this.txtLongitude);
            this.panelEx1.Controls.Add(this.txtAlias);
            this.panelEx1.Controls.Add(this.labelX1);
            this.panelEx1.Controls.Add(this.labelX4);
            this.panelEx1.Controls.Add(this.labelX5);
            this.panelEx1.Controls.Add(this.txtNhaCungCap);
            this.panelEx1.Controls.Add(this.labelX6);
            this.panelEx1.Controls.Add(this.panelEx2);
            this.panelEx1.Controls.Add(this.txtUserName);
            this.panelEx1.Controls.Add(this.txtLoai);
            this.panelEx1.Controls.Add(this.labelX3);
            this.panelEx1.Controls.Add(this.txtPassword);
            this.panelEx1.Controls.Add(this.txtAPIKey);
            this.panelEx1.Controls.Add(this.labelX2);
            this.panelEx1.DisabledBackColor = System.Drawing.Color.Empty;
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEx1.Location = new System.Drawing.Point(0, 0);
            this.panelEx1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(2019, 1461);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.panelEx1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 32;
            // 
            // textBoxX2
            // 
            // 
            // 
            // 
            this.textBoxX2.Border.Class = "TextBoxBorder";
            this.textBoxX2.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX2.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.textBoxX2.FocusHighlightEnabled = true;
            this.textBoxX2.Location = new System.Drawing.Point(1081, 247);
            this.textBoxX2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxX2.Multiline = true;
            this.textBoxX2.Name = "textBoxX2";
            this.textBoxX2.Size = new System.Drawing.Size(869, 226);
            this.textBoxX2.TabIndex = 226;
            this.textBoxX2.UseSystemPasswordChar = true;
            // 
            // textBoxX1
            // 
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.textBoxX1.FocusHighlightEnabled = true;
            this.textBoxX1.Location = new System.Drawing.Point(190, 247);
            this.textBoxX1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxX1.Multiline = true;
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(869, 226);
            this.textBoxX1.TabIndex = 225;
            this.textBoxX1.UseSystemPasswordChar = true;
            // 
            // labelX9
            // 
            this.labelX9.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Location = new System.Drawing.Point(1458, 209);
            this.labelX9.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(183, 27);
            this.labelX9.TabIndex = 224;
            this.labelX9.Text = "CÔNG DỤNG";
            // 
            // mListViewData
            // 
            this.mListViewData.AllColumns.Add(this.olvColumn2);
            this.mListViewData.AllColumns.Add(this.olvColumn17);
            this.mListViewData.AllColumns.Add(this.olvColumn18);
            this.mListViewData.AllColumns.Add(this.olvColumn19);
            this.mListViewData.AllColumns.Add(this.olvColumn20);
            this.mListViewData.AllColumns.Add(this.olvColumn21);
            this.mListViewData.AllColumns.Add(this.olvColumn22);
            this.mListViewData.AllColumns.Add(this.olvColumn23);
            this.mListViewData.AllColumns.Add(this.olvColumn24);
            this.mListViewData.AllColumns.Add(this.olvColumn25);
            this.mListViewData.AllColumns.Add(this.olvColumn26);
            this.mListViewData.AllColumns.Add(this.olvColumn27);
            this.mListViewData.AllColumns.Add(this.olvColumn28);
            this.mListViewData.AllColumns.Add(this.olvColumn29);
            this.mListViewData.AllColumns.Add(this.olvColumn32);
            this.mListViewData.AllColumns.Add(this.olvColumn37);
            this.mListViewData.AllColumns.Add(this.olvColumn38);
            this.mListViewData.AllColumns.Add(this.olvColumn39);
            this.mListViewData.AllColumns.Add(this.olvColumn41);
            this.mListViewData.AllColumns.Add(this.olvColumn42);
            this.mListViewData.AlternateRowBackColor = System.Drawing.Color.WhiteSmoke;
            this.mListViewData.AutoArrange = false;
            this.mListViewData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.mListViewData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mListViewData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumn2,
            this.olvColumn17,
            this.olvColumn18,
            this.olvColumn19,
            this.olvColumn20,
            this.olvColumn21,
            this.olvColumn22,
            this.olvColumn23,
            this.olvColumn24,
            this.olvColumn25,
            this.olvColumn26,
            this.olvColumn27,
            this.olvColumn28,
            this.olvColumn29,
            this.olvColumn32,
            this.olvColumn37,
            this.olvColumn38,
            this.olvColumn39,
            this.olvColumn41,
            this.olvColumn42});
            this.mListViewData.FullRowSelect = true;
            this.mListViewData.GridLines = true;
            this.mListViewData.HideSelection = false;
            this.mListViewData.Location = new System.Drawing.Point(13, 539);
            this.mListViewData.Margin = new System.Windows.Forms.Padding(4);
            this.mListViewData.MenuLabelSortAscending = "Sắp xếp tăng dần theo \'{0}\'";
            this.mListViewData.MultiSelect = false;
            this.mListViewData.Name = "mListViewData";
            this.mListViewData.ShowGroups = false;
            this.mListViewData.Size = new System.Drawing.Size(1993, 716);
            this.mListViewData.SortGroupItemsByPrimaryColumn = false;
            this.mListViewData.TabIndex = 223;
            this.mListViewData.UnfocusedHighlightBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.mListViewData.UnfocusedHighlightForegroundColor = System.Drawing.Color.White;
            this.mListViewData.UseAlternatingBackColors = true;
            this.mListViewData.UseCompatibleStateImageBehavior = false;
            this.mListViewData.UseCustomSelectionColors = true;
            this.mListViewData.UseFiltering = true;
            this.mListViewData.View = System.Windows.Forms.View.Details;
            // 
            // olvColumn2
            // 
            this.olvColumn2.AspectName = "";
            this.olvColumn2.CellPadding = null;
            this.olvColumn2.Text = "";
            this.olvColumn2.Width = 10;
            // 
            // olvColumn17
            // 
            this.olvColumn17.AspectName = "ThuocTinh";
            this.olvColumn17.CellPadding = null;
            this.olvColumn17.Text = "Thuộc tính 1(Option1 Name)";
            // 
            // olvColumn18
            // 
            this.olvColumn18.AspectName = "GiaTriThuocTinh";
            this.olvColumn18.CellPadding = null;
            this.olvColumn18.Text = "Giá trị thuộc tính 1(Option1 Value)";
            // 
            // olvColumn19
            // 
            this.olvColumn19.AspectName = "ThuocTinh2";
            this.olvColumn19.CellPadding = null;
            this.olvColumn19.Text = "Thuộc tính 2(Option2 Name)";
            // 
            // olvColumn20
            // 
            this.olvColumn20.AspectName = "GiaTriThuocTinh2";
            this.olvColumn20.CellPadding = null;
            this.olvColumn20.Text = "Giá trị thuộc tính 2(Option2 Value)";
            // 
            // olvColumn21
            // 
            this.olvColumn21.AspectName = "ThuocTinh3";
            this.olvColumn21.CellPadding = null;
            this.olvColumn21.Text = "Thuộc tính 3(Option3 Name)";
            // 
            // olvColumn22
            // 
            this.olvColumn22.AspectName = "GiaTriThuocTinh3";
            this.olvColumn22.CellPadding = null;
            this.olvColumn22.Text = "Giá trị thuộc tính 1(Option3 Value)";
            // 
            // olvColumn23
            // 
            this.olvColumn23.AspectName = "SKU";
            this.olvColumn23.CellPadding = null;
            this.olvColumn23.Text = "Mã (SKU)";
            // 
            // olvColumn24
            // 
            this.olvColumn24.AspectName = "QuanLyKho";
            this.olvColumn24.CellPadding = null;
            this.olvColumn24.Text = "Quản lý kho";
            // 
            // olvColumn25
            // 
            this.olvColumn25.AspectName = "SoLuong";
            this.olvColumn25.CellPadding = null;
            this.olvColumn25.Text = "Số lượng";
            // 
            // olvColumn26
            // 
            this.olvColumn26.AspectName = "ChoPhepBan";
            this.olvColumn26.CellPadding = null;
            this.olvColumn26.Text = "Cho phép bán";
            // 
            // olvColumn27
            // 
            this.olvColumn27.AspectName = "Variant";
            this.olvColumn27.CellPadding = null;
            this.olvColumn27.Text = "Variant Fulfillment Service";
            // 
            // olvColumn28
            // 
            this.olvColumn28.AspectName = "Gia";
            this.olvColumn28.CellPadding = null;
            this.olvColumn28.Text = "Giá";
            // 
            // olvColumn29
            // 
            this.olvColumn29.AspectName = "GiaSoSanh";
            this.olvColumn29.CellPadding = null;
            this.olvColumn29.Text = "Giá so sánh";
            // 
            // olvColumn32
            // 
            this.olvColumn32.AspectName = "MaVach";
            this.olvColumn32.CellPadding = null;
            this.olvColumn32.Text = "Mã vạch(Barcode)";
            // 
            // olvColumn37
            // 
            this.olvColumn37.AspectName = "CanNang";
            this.olvColumn37.CellPadding = null;
            this.olvColumn37.Text = "Cân nặng";
            // 
            // olvColumn38
            // 
            this.olvColumn38.AspectName = "DonViCan";
            this.olvColumn38.CellPadding = null;
            this.olvColumn38.Text = "Đơn vị cân nặng";
            // 
            // olvColumn39
            // 
            this.olvColumn39.AspectName = "AnhPhienBan";
            this.olvColumn39.CellPadding = null;
            this.olvColumn39.Text = "Ảnh phiên bản";
            // 
            // olvColumn41
            // 
            this.olvColumn41.AspectName = "ID";
            this.olvColumn41.CellPadding = null;
            this.olvColumn41.Text = "Id sản phẩm";
            // 
            // olvColumn42
            // 
            this.olvColumn42.AspectName = "IDTuyChon";
            this.olvColumn42.CellPadding = null;
            this.olvColumn42.Text = "Id tùy chọn";
            // 
            // checkBoxAn
            // 
            this.checkBoxAn.AutoSize = true;
            this.checkBoxAn.Location = new System.Drawing.Point(333, 176);
            this.checkBoxAn.Name = "checkBoxAn";
            this.checkBoxAn.Size = new System.Drawing.Size(52, 25);
            this.checkBoxAn.TabIndex = 75;
            this.checkBoxAn.Text = "Ẩn";
            this.checkBoxAn.UseVisualStyleBackColor = true;
            // 
            // checkBoxHienThi
            // 
            this.checkBoxHienThi.AutoSize = true;
            this.checkBoxHienThi.Location = new System.Drawing.Point(189, 176);
            this.checkBoxHienThi.Name = "checkBoxHienThi";
            this.checkBoxHienThi.Size = new System.Drawing.Size(89, 25);
            this.checkBoxHienThi.TabIndex = 74;
            this.checkBoxHienThi.Text = "Hiển thị";
            this.checkBoxHienThi.UseVisualStyleBackColor = true;
            // 
            // txtHassIO_KEY
            // 
            // 
            // 
            // 
            this.txtHassIO_KEY.Border.Class = "TextBoxBorder";
            this.txtHassIO_KEY.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtHassIO_KEY.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtHassIO_KEY.FocusHighlightEnabled = true;
            this.txtHassIO_KEY.Location = new System.Drawing.Point(556, 1319);
            this.txtHassIO_KEY.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtHassIO_KEY.Name = "txtHassIO_KEY";
            this.txtHassIO_KEY.Size = new System.Drawing.Size(420, 27);
            this.txtHassIO_KEY.TabIndex = 9;
            this.txtHassIO_KEY.UseSystemPasswordChar = true;
            this.txtHassIO_KEY.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // labelX8
            // 
            this.labelX8.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Location = new System.Drawing.Point(503, 209);
            this.labelX8.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(183, 27);
            this.labelX8.TabIndex = 70;
            this.labelX8.Text = "THÔNG SỐ KĨ THUẬT";
            // 
            // txtTag
            // 
            // 
            // 
            // 
            this.txtTag.Border.Class = "TextBoxBorder";
            this.txtTag.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTag.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtTag.FocusHighlightEnabled = true;
            this.txtTag.Location = new System.Drawing.Point(190, 133);
            this.txtTag.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTag.Name = "txtTag";
            this.txtTag.Size = new System.Drawing.Size(1276, 27);
            this.txtTag.TabIndex = 7;
            this.txtTag.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // labelX7
            // 
            this.labelX7.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.Location = new System.Drawing.Point(12, 131);
            this.labelX7.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(130, 27);
            this.labelX7.TabIndex = 65;
            this.labelX7.Text = "Tags";
            // 
            // txtTenSanPham
            // 
            // 
            // 
            // 
            this.txtTenSanPham.Border.Class = "TextBoxBorder";
            this.txtTenSanPham.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTenSanPham.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtTenSanPham.FocusHighlightEnabled = true;
            this.txtTenSanPham.Location = new System.Drawing.Point(190, 56);
            this.txtTenSanPham.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTenSanPham.Name = "txtTenSanPham";
            this.txtTenSanPham.Size = new System.Drawing.Size(1276, 27);
            this.txtTenSanPham.TabIndex = 2;
            this.txtTenSanPham.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // txtLongitude
            // 
            // 
            // 
            // 
            this.txtLongitude.Border.Class = "TextBoxBorder";
            this.txtLongitude.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtLongitude.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtLongitude.FocusHighlightEnabled = true;
            this.txtLongitude.Location = new System.Drawing.Point(35, 1333);
            this.txtLongitude.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLongitude.Name = "txtLongitude";
            this.txtLongitude.Size = new System.Drawing.Size(420, 27);
            this.txtLongitude.TabIndex = 6;
            this.txtLongitude.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // txtAlias
            // 
            // 
            // 
            // 
            this.txtAlias.Border.Class = "TextBoxBorder";
            this.txtAlias.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtAlias.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtAlias.FocusHighlightEnabled = true;
            this.txtAlias.Location = new System.Drawing.Point(190, 17);
            this.txtAlias.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAlias.Name = "txtAlias";
            this.txtAlias.Size = new System.Drawing.Size(1276, 27);
            this.txtAlias.TabIndex = 0;
            this.txtAlias.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // labelX1
            // 
            this.labelX1.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(13, 54);
            this.labelX1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(130, 27);
            this.labelX1.TabIndex = 62;
            this.labelX1.Text = "Tên sản phẩm";
            // 
            // labelX4
            // 
            this.labelX4.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Location = new System.Drawing.Point(12, 209);
            this.labelX4.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(130, 27);
            this.labelX4.TabIndex = 60;
            this.labelX4.Text = "Nội dung";
            // 
            // labelX5
            // 
            this.labelX5.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Location = new System.Drawing.Point(13, 15);
            this.labelX5.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(130, 27);
            this.labelX5.TabIndex = 63;
            this.labelX5.Text = "Đường dẫn / Alias";
            // 
            // txtNhaCungCap
            // 
            // 
            // 
            // 
            this.txtNhaCungCap.Border.Class = "TextBoxBorder";
            this.txtNhaCungCap.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtNhaCungCap.FocusHighlightColor = System.Drawing.Color.LightYellow;
            this.txtNhaCungCap.FocusHighlightEnabled = true;
            this.txtNhaCungCap.Location = new System.Drawing.Point(190, 95);
            this.txtNhaCungCap.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNhaCungCap.Name = "txtNhaCungCap";
            this.txtNhaCungCap.Size = new System.Drawing.Size(420, 27);
            this.txtNhaCungCap.TabIndex = 4;
            this.txtNhaCungCap.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Control_KeyDown);
            // 
            // labelX6
            // 
            this.labelX6.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Location = new System.Drawing.Point(13, 93);
            this.labelX6.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(130, 27);
            this.labelX6.TabIndex = 61;
            this.labelX6.Text = "Nhà cung cấp";
            // 
            // panelEx2
            // 
            this.panelEx2.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelEx2.Controls.Add(this.btnSave);
            this.panelEx2.DisabledBackColor = System.Drawing.Color.Empty;
            this.panelEx2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelEx2.Location = new System.Drawing.Point(0, 1413);
            this.panelEx2.Margin = new System.Windows.Forms.Padding(4);
            this.panelEx2.Name = "panelEx2";
            this.panelEx2.Padding = new System.Windows.Forms.Padding(1);
            this.panelEx2.Size = new System.Drawing.Size(2019, 48);
            this.panelEx2.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx2.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.panelEx2.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.panelEx2.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx2.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx2.Style.BorderSide = DevComponents.DotNetBar.eBorderSide.Top;
            this.panelEx2.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx2.Style.GradientAngle = 90;
            this.panelEx2.TabIndex = 52;
            // 
            // btnSave
            // 
            this.btnSave.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.btnSave.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnSave.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSave.Image = global::MediboxAssistant.Properties.Resources.Save_32x32;
            this.btnSave.Location = new System.Drawing.Point(1870, 1);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Shortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlS);
            this.btnSave.Size = new System.Drawing.Size(148, 46);
            this.btnSave.TabIndex = 100;
            this.btnSave.Text = "Lưu";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // FormEditSanPhamWeb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2019, 1461);
            this.Controls.Add(this.panelEx1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormEditSanPhamWeb";
            this.Text = "Cập Nhật Sản Phẩm Web";
            this.Load += new System.EventHandler(this.Database_Load);
            this.panelEx1.ResumeLayout(false);
            this.panelEx1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mListViewData)).EndInit();
            this.panelEx2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.TextBoxX txtUserName;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.Controls.TextBoxX txtAPIKey;
        private DevComponents.DotNetBar.LabelX txtPassword;
        private DevComponents.DotNetBar.Controls.TextBoxX txtLoai;
        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.PanelEx panelEx2;
        private DevComponents.DotNetBar.ButtonX btnSave;
        private DevComponents.DotNetBar.Controls.TextBoxX txtTag;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.Controls.TextBoxX txtTenSanPham;
        private DevComponents.DotNetBar.Controls.TextBoxX txtLongitude;
        private DevComponents.DotNetBar.Controls.TextBoxX txtAlias;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.Controls.TextBoxX txtNhaCungCap;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.Controls.TextBoxX txtHassIO_KEY;
        private DevComponents.DotNetBar.LabelX labelX8;
        private System.Windows.Forms.CheckBox checkBoxAn;
        private System.Windows.Forms.CheckBox checkBoxHienThi;
        private Sanita.Utility.UI.ObjectListView mListViewData;
        private Sanita.Utility.UI.OLVColumn olvColumn2;
        private Sanita.Utility.UI.OLVColumn olvColumn17;
        private Sanita.Utility.UI.OLVColumn olvColumn18;
        private Sanita.Utility.UI.OLVColumn olvColumn19;
        private Sanita.Utility.UI.OLVColumn olvColumn20;
        private Sanita.Utility.UI.OLVColumn olvColumn21;
        private Sanita.Utility.UI.OLVColumn olvColumn22;
        private Sanita.Utility.UI.OLVColumn olvColumn23;
        private Sanita.Utility.UI.OLVColumn olvColumn24;
        private Sanita.Utility.UI.OLVColumn olvColumn25;
        private Sanita.Utility.UI.OLVColumn olvColumn26;
        private Sanita.Utility.UI.OLVColumn olvColumn27;
        private Sanita.Utility.UI.OLVColumn olvColumn28;
        private Sanita.Utility.UI.OLVColumn olvColumn29;
        private Sanita.Utility.UI.OLVColumn olvColumn32;
        private Sanita.Utility.UI.OLVColumn olvColumn37;
        private Sanita.Utility.UI.OLVColumn olvColumn38;
        private Sanita.Utility.UI.OLVColumn olvColumn39;
        private Sanita.Utility.UI.OLVColumn olvColumn41;
        private Sanita.Utility.UI.OLVColumn olvColumn42;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX2;
    }
}