﻿namespace Medibox
{
    partial class FormViewSanPhamWeb
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.mListViewData = new Sanita.Utility.UI.ObjectListView();
            this.olvColumn2 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.txtSearch = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.panelEx3 = new DevComponents.DotNetBar.PanelEx();
            this.btnAdd = new DevComponents.DotNetBar.ButtonX();
            this.btnRefresh = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.labelItem1 = new DevComponents.DotNetBar.LabelItem();
            this.btnImport = new DevComponents.DotNetBar.ButtonItem();
            this.btnExport = new DevComponents.DotNetBar.ButtonItem();
            this.btnExit = new DevComponents.DotNetBar.ButtonItem();
            this.lblBenhAn = new DevComponents.DotNetBar.LabelX();
            this.DichVuMenuBar = new DevComponents.DotNetBar.ContextMenuBar();
            this.DichVuMenu = new DevComponents.DotNetBar.ButtonItem();
            this.labelItem2 = new DevComponents.DotNetBar.LabelItem();
            this.btnXoa = new DevComponents.DotNetBar.ButtonItem();
            this.olvColumn4 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn1 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn3 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn6 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn7 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn8 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn9 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn10 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.DataProgress = new DevComponents.DotNetBar.Controls.CircularProgress();
            this.controlContainerItem1 = new DevComponents.DotNetBar.ControlContainerItem();
            this.olvColumn5 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn11 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn12 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn13 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn14 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn15 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn16 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn17 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn18 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn19 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn20 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn21 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn22 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn23 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn24 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn25 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn26 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn27 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn28 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn29 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn30 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn31 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn32 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn33 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn34 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn35 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn36 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn37 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn38 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn39 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn40 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn41 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.olvColumn42 = ((Sanita.Utility.UI.OLVColumn)(new Sanita.Utility.UI.OLVColumn()));
            this.TimerSearch = new System.Windows.Forms.Timer(this.components);
            this.panelEx1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mListViewData)).BeginInit();
            this.panelEx3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DichVuMenuBar)).BeginInit();
            this.SuspendLayout();
            // 
            // panelEx1
            // 
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.panelEx1.Controls.Add(this.mListViewData);
            this.panelEx1.Controls.Add(this.txtSearch);
            this.panelEx1.Controls.Add(this.panelEx3);
            this.panelEx1.DisabledBackColor = System.Drawing.Color.Empty;
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEx1.Location = new System.Drawing.Point(0, 0);
            this.panelEx1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(1736, 819);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.panelEx1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 32;
            // 
            // mListViewData
            // 
            this.mListViewData.AllColumns.Add(this.olvColumn2);
            this.mListViewData.AllColumns.Add(this.olvColumn5);
            this.mListViewData.AllColumns.Add(this.olvColumn11);
            this.mListViewData.AllColumns.Add(this.olvColumn12);
            this.mListViewData.AllColumns.Add(this.olvColumn13);
            this.mListViewData.AllColumns.Add(this.olvColumn14);
            this.mListViewData.AllColumns.Add(this.olvColumn15);
            this.mListViewData.AllColumns.Add(this.olvColumn16);
            this.mListViewData.AllColumns.Add(this.olvColumn17);
            this.mListViewData.AllColumns.Add(this.olvColumn18);
            this.mListViewData.AllColumns.Add(this.olvColumn19);
            this.mListViewData.AllColumns.Add(this.olvColumn20);
            this.mListViewData.AllColumns.Add(this.olvColumn21);
            this.mListViewData.AllColumns.Add(this.olvColumn22);
            this.mListViewData.AllColumns.Add(this.olvColumn23);
            this.mListViewData.AllColumns.Add(this.olvColumn24);
            this.mListViewData.AllColumns.Add(this.olvColumn25);
            this.mListViewData.AllColumns.Add(this.olvColumn26);
            this.mListViewData.AllColumns.Add(this.olvColumn27);
            this.mListViewData.AllColumns.Add(this.olvColumn28);
            this.mListViewData.AllColumns.Add(this.olvColumn29);
            this.mListViewData.AllColumns.Add(this.olvColumn30);
            this.mListViewData.AllColumns.Add(this.olvColumn31);
            this.mListViewData.AllColumns.Add(this.olvColumn32);
            this.mListViewData.AllColumns.Add(this.olvColumn33);
            this.mListViewData.AllColumns.Add(this.olvColumn34);
            this.mListViewData.AllColumns.Add(this.olvColumn35);
            this.mListViewData.AllColumns.Add(this.olvColumn36);
            this.mListViewData.AllColumns.Add(this.olvColumn37);
            this.mListViewData.AllColumns.Add(this.olvColumn38);
            this.mListViewData.AllColumns.Add(this.olvColumn39);
            this.mListViewData.AllColumns.Add(this.olvColumn40);
            this.mListViewData.AllColumns.Add(this.olvColumn41);
            this.mListViewData.AllColumns.Add(this.olvColumn42);
            this.mListViewData.AlternateRowBackColor = System.Drawing.Color.WhiteSmoke;
            this.mListViewData.AutoArrange = false;
            this.mListViewData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.mListViewData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mListViewData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumn2,
            this.olvColumn5,
            this.olvColumn11,
            this.olvColumn12,
            this.olvColumn13,
            this.olvColumn14,
            this.olvColumn15,
            this.olvColumn16,
            this.olvColumn17,
            this.olvColumn18,
            this.olvColumn19,
            this.olvColumn20,
            this.olvColumn21,
            this.olvColumn22,
            this.olvColumn23,
            this.olvColumn24,
            this.olvColumn25,
            this.olvColumn26,
            this.olvColumn27,
            this.olvColumn28,
            this.olvColumn29,
            this.olvColumn30,
            this.olvColumn31,
            this.olvColumn32,
            this.olvColumn33,
            this.olvColumn34,
            this.olvColumn35,
            this.olvColumn36,
            this.olvColumn37,
            this.olvColumn38,
            this.olvColumn39,
            this.olvColumn40,
            this.olvColumn41,
            this.olvColumn42});
            this.mListViewData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mListViewData.FullRowSelect = true;
            this.mListViewData.GridLines = true;
            this.mListViewData.HideSelection = false;
            this.mListViewData.Location = new System.Drawing.Point(0, 103);
            this.mListViewData.Margin = new System.Windows.Forms.Padding(4);
            this.mListViewData.MenuLabelSortAscending = "Sắp xếp tăng dần theo \'{0}\'";
            this.mListViewData.MultiSelect = false;
            this.mListViewData.Name = "mListViewData";
            this.mListViewData.ShowGroups = false;
            this.mListViewData.Size = new System.Drawing.Size(1736, 716);
            this.mListViewData.SortGroupItemsByPrimaryColumn = false;
            this.mListViewData.TabIndex = 222;
            this.mListViewData.UnfocusedHighlightBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.mListViewData.UnfocusedHighlightForegroundColor = System.Drawing.Color.White;
            this.mListViewData.UseAlternatingBackColors = true;
            this.mListViewData.UseCompatibleStateImageBehavior = false;
            this.mListViewData.UseCustomSelectionColors = true;
            this.mListViewData.UseFiltering = true;
            this.mListViewData.View = System.Windows.Forms.View.Details;
            this.mListViewData.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.mListViewData_MouseDoubleClick);
            this.mListViewData.Resize += new System.EventHandler(this.mListViewData_Resize);
            // 
            // olvColumn2
            // 
            this.olvColumn2.AspectName = "";
            this.olvColumn2.CellPadding = null;
            this.olvColumn2.Text = "";
            this.olvColumn2.Width = 10;
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            // 
            // 
            // 
            this.txtSearch.Border.BorderLeftWidth = -1;
            this.txtSearch.Border.BorderRightWidth = -1;
            this.txtSearch.Border.Class = "TextBoxBorder";
            this.txtSearch.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtSearch.ButtonCustom.Visible = true;
            this.txtSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtSearch.FocusHighlightEnabled = true;
            this.txtSearch.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(0, 71);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(4);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.PreventEnterBeep = true;
            this.txtSearch.Size = new System.Drawing.Size(1736, 32);
            this.txtSearch.TabIndex = 221;
            this.txtSearch.WatermarkColor = System.Drawing.Color.DimGray;
            this.txtSearch.WatermarkText = "Tìm kiếm (Ctrl+F)";
            this.txtSearch.ButtonCustomClick += new System.EventHandler(this.txtSearch_ButtonCustomClick);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // panelEx3
            // 
            this.panelEx3.CanvasColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.panelEx3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelEx3.Controls.Add(this.btnAdd);
            this.panelEx3.Controls.Add(this.btnRefresh);
            this.panelEx3.Controls.Add(this.buttonX1);
            this.panelEx3.Controls.Add(this.lblBenhAn);
            this.panelEx3.Controls.Add(this.DichVuMenuBar);
            this.panelEx3.DisabledBackColor = System.Drawing.Color.Empty;
            this.panelEx3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEx3.Location = new System.Drawing.Point(0, 0);
            this.panelEx3.Margin = new System.Windows.Forms.Padding(4);
            this.panelEx3.Name = "panelEx3";
            this.panelEx3.Padding = new System.Windows.Forms.Padding(1);
            this.panelEx3.Size = new System.Drawing.Size(1736, 71);
            this.panelEx3.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx3.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.panelEx3.Style.BackColor2.Color = System.Drawing.SystemColors.Control;
            this.panelEx3.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx3.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx3.Style.BorderSide = DevComponents.DotNetBar.eBorderSide.Top;
            this.panelEx3.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx3.Style.GradientAngle = 90;
            this.panelEx3.TabIndex = 220;
            // 
            // btnAdd
            // 
            this.btnAdd.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.btnAdd.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnAdd.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnAdd.Image = global::MediboxAssistant.Properties.Resources.Add_32x32;
            this.btnAdd.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnAdd.Location = new System.Drawing.Point(236, 1);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(136, 69);
            this.btnAdd.TabIndex = 147;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.btnRefresh.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnRefresh.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnRefresh.Image = global::MediboxAssistant.Properties.Resources.Refresh_32__1_;
            this.btnRefresh.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnRefresh.Location = new System.Drawing.Point(120, 1);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(116, 69);
            this.btnRefresh.TabIndex = 148;
            this.btnRefresh.Text = "Làm Mới";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.AutoExpandOnClick = true;
            this.buttonX1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.buttonX1.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonX1.Image = global::MediboxAssistant.Properties.Resources.Open_32x32;
            this.buttonX1.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonX1.Location = new System.Drawing.Point(1, 1);
            this.buttonX1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(119, 69);
            this.buttonX1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem1,
            this.btnImport,
            this.btnExport,
            this.btnExit});
            this.buttonX1.TabIndex = 146;
            this.buttonX1.Text = "File";
            // 
            // labelItem1
            // 
            this.labelItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelItem1.BorderType = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.labelItem1.ForeColor = System.Drawing.Color.Black;
            this.labelItem1.Name = "labelItem1";
            this.labelItem1.PaddingBottom = 3;
            this.labelItem1.PaddingLeft = 10;
            this.labelItem1.PaddingTop = 3;
            this.labelItem1.SingleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.labelItem1.Text = "File";
            // 
            // btnImport
            // 
            this.btnImport.GlobalItem = false;
            this.btnImport.Name = "btnImport";
            this.btnImport.Text = "Thêm Từ File Excel";
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnExport
            // 
            this.btnExport.GlobalItem = false;
            this.btnExport.Name = "btnExport";
            this.btnExport.Text = "Xuất File Excel";
            // 
            // btnExit
            // 
            this.btnExit.BeginGroup = true;
            this.btnExit.GlobalItem = false;
            this.btnExit.Name = "btnExit";
            this.btnExit.Text = "Đóng";
            // 
            // lblBenhAn
            // 
            // 
            // 
            // 
            this.lblBenhAn.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.lblBenhAn.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblBenhAn.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblBenhAn.ForeColor = System.Drawing.Color.Maroon;
            this.lblBenhAn.Location = new System.Drawing.Point(1312, 1);
            this.lblBenhAn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lblBenhAn.Name = "lblBenhAn";
            this.lblBenhAn.Size = new System.Drawing.Size(423, 69);
            this.lblBenhAn.TabIndex = 9;
            this.lblBenhAn.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // DichVuMenuBar
            // 
            this.DichVuMenuBar.AntiAlias = true;
            this.DichVuMenuBar.DockSide = DevComponents.DotNetBar.eDockSide.Top;
            this.DichVuMenuBar.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DichVuMenuBar.IsMaximized = false;
            this.DichVuMenuBar.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.DichVuMenu});
            this.DichVuMenuBar.Location = new System.Drawing.Point(749, 13);
            this.DichVuMenuBar.Margin = new System.Windows.Forms.Padding(4);
            this.DichVuMenuBar.Name = "DichVuMenuBar";
            this.DichVuMenuBar.Size = new System.Drawing.Size(138, 29);
            this.DichVuMenuBar.Stretch = true;
            this.DichVuMenuBar.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.DichVuMenuBar.TabIndex = 224;
            this.DichVuMenuBar.TabStop = false;
            // 
            // DichVuMenu
            // 
            this.DichVuMenu.AutoExpandOnClick = true;
            this.DichVuMenu.Name = "DichVuMenu";
            this.DichVuMenu.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem2,
            this.btnXoa});
            this.DichVuMenu.Text = "Dịch Vụ";
            // 
            // labelItem2
            // 
            this.labelItem2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelItem2.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.labelItem2.BorderType = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.labelItem2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(21)))), ((int)(((byte)(110)))));
            this.labelItem2.Name = "labelItem2";
            this.labelItem2.PaddingBottom = 1;
            this.labelItem2.PaddingLeft = 10;
            this.labelItem2.PaddingTop = 1;
            this.labelItem2.SingleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.labelItem2.Text = "Người Dùng";
            // 
            // btnXoa
            // 
            this.btnXoa.BeginGroup = true;
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Text = "Xóa";
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // olvColumn4
            // 
            this.olvColumn4.AspectName = "UserCode";
            this.olvColumn4.CellPadding = null;
            this.olvColumn4.Text = "Code";
            this.olvColumn4.Width = 120;
            // 
            // olvColumn1
            // 
            this.olvColumn1.AspectName = "UserName";
            this.olvColumn1.CellPadding = null;
            this.olvColumn1.Text = "Name";
            this.olvColumn1.Width = 200;
            // 
            // olvColumn3
            // 
            this.olvColumn3.AspectName = "APIKey";
            this.olvColumn3.CellPadding = null;
            this.olvColumn3.Text = "API Key";
            this.olvColumn3.Width = 150;
            // 
            // olvColumn6
            // 
            this.olvColumn6.AspectName = "LocaltionName";
            this.olvColumn6.CellPadding = null;
            this.olvColumn6.Text = "Localtion Name";
            this.olvColumn6.Width = 150;
            // 
            // olvColumn7
            // 
            this.olvColumn7.AspectName = "Latitude";
            this.olvColumn7.CellPadding = null;
            this.olvColumn7.Text = "Latitude";
            this.olvColumn7.Width = 100;
            // 
            // olvColumn8
            // 
            this.olvColumn8.AspectName = "Longitude";
            this.olvColumn8.CellPadding = null;
            this.olvColumn8.Text = "Longitude";
            this.olvColumn8.Width = 100;
            // 
            // olvColumn9
            // 
            this.olvColumn9.AspectName = "HassIO_URL";
            this.olvColumn9.CellPadding = null;
            this.olvColumn9.Text = "HassIO_URL";
            this.olvColumn9.Width = 150;
            // 
            // olvColumn10
            // 
            this.olvColumn10.AspectName = "HassIO_KEY";
            this.olvColumn10.CellPadding = null;
            this.olvColumn10.Text = "HassIO_KEY";
            this.olvColumn10.Width = 150;
            // 
            // DataProgress
            // 
            this.DataProgress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            // 
            // 
            // 
            this.DataProgress.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.DataProgress.Location = new System.Drawing.Point(3, 54);
            this.DataProgress.Name = "DataProgress";
            this.DataProgress.ProgressBarType = DevComponents.DotNetBar.eCircularProgressType.Dot;
            this.DataProgress.ProgressColor = System.Drawing.Color.Maroon;
            this.DataProgress.ProgressTextColor = System.Drawing.Color.Maroon;
            this.DataProgress.ProgressTextFormat = "";
            this.DataProgress.ProgressTextVisible = true;
            this.DataProgress.Size = new System.Drawing.Size(50, 50);
            this.DataProgress.Style = DevComponents.DotNetBar.eDotNetBarStyle.OfficeXP;
            this.DataProgress.TabIndex = 223;
            this.DataProgress.Value = 100;
            // 
            // controlContainerItem1
            // 
            this.controlContainerItem1.AllowItemResize = true;
            this.controlContainerItem1.Control = this.DataProgress;
            this.controlContainerItem1.MenuVisibility = DevComponents.DotNetBar.eMenuVisibility.VisibleAlways;
            this.controlContainerItem1.Name = "controlContainerItem1";
            // 
            // olvColumn5
            // 
            this.olvColumn5.AspectName = "Alias";
            this.olvColumn5.CellPadding = null;
            this.olvColumn5.Text = "Đường dẫn / Alias";
            // 
            // olvColumn11
            // 
            this.olvColumn11.AspectName = "TenSanPham";
            this.olvColumn11.CellPadding = null;
            this.olvColumn11.Text = "Tên sản phẩm";
            // 
            // olvColumn12
            // 
            this.olvColumn12.AspectName = "NoiDung";
            this.olvColumn12.CellPadding = null;
            this.olvColumn12.Text = "Nội dung";
            // 
            // olvColumn13
            // 
            this.olvColumn13.AspectName = "NhaCungCap";
            this.olvColumn13.CellPadding = null;
            this.olvColumn13.Text = "Nhà cung cấp";
            // 
            // olvColumn14
            // 
            this.olvColumn14.AspectName = "Loai";
            this.olvColumn14.CellPadding = null;
            this.olvColumn14.Text = "Loại";
            // 
            // olvColumn15
            // 
            this.olvColumn15.AspectName = "Tag";
            this.olvColumn15.CellPadding = null;
            this.olvColumn15.Text = "Tag";
            // 
            // olvColumn16
            // 
            this.olvColumn16.AspectName = "HienThi";
            this.olvColumn16.CellPadding = null;
            this.olvColumn16.Text = "Hiển thị";
            // 
            // olvColumn17
            // 
            this.olvColumn17.AspectName = "ThuocTinh";
            this.olvColumn17.CellPadding = null;
            this.olvColumn17.Text = "Thuộc tính 1(Option1 Name)";
            // 
            // olvColumn18
            // 
            this.olvColumn18.AspectName = "GiaTriThuocTinh";
            this.olvColumn18.CellPadding = null;
            this.olvColumn18.Text = "Giá trị thuộc tính 1(Option1 Value)";
            // 
            // olvColumn19
            // 
            this.olvColumn19.AspectName = "ThuocTinh2";
            this.olvColumn19.CellPadding = null;
            this.olvColumn19.Text = "Thuộc tính 2(Option2 Name)";
            // 
            // olvColumn20
            // 
            this.olvColumn20.AspectName = "GiaTriThuocTinh2";
            this.olvColumn20.CellPadding = null;
            this.olvColumn20.Text = "Giá trị thuộc tính 2(Option2 Value)";
            // 
            // olvColumn21
            // 
            this.olvColumn21.AspectName = "ThuocTinh3";
            this.olvColumn21.CellPadding = null;
            this.olvColumn21.Text = "Thuộc tính 3(Option3 Name)";
            // 
            // olvColumn22
            // 
            this.olvColumn22.AspectName = "GiaTriThuocTinh3";
            this.olvColumn22.CellPadding = null;
            this.olvColumn22.Text = "Giá trị thuộc tính 1(Option3 Value)";
            // 
            // olvColumn23
            // 
            this.olvColumn23.AspectName = "SKU";
            this.olvColumn23.CellPadding = null;
            this.olvColumn23.Text = "Mã (SKU)";
            // 
            // olvColumn24
            // 
            this.olvColumn24.AspectName = "QuanLyKho";
            this.olvColumn24.CellPadding = null;
            this.olvColumn24.Text = "Quản lý kho";
            // 
            // olvColumn25
            // 
            this.olvColumn25.AspectName = "SoLuong";
            this.olvColumn25.CellPadding = null;
            this.olvColumn25.Text = "Số lượng";
            // 
            // olvColumn26
            // 
            this.olvColumn26.AspectName = "ChoPhepBan";
            this.olvColumn26.CellPadding = null;
            this.olvColumn26.Text = "Cho phép bán";
            // 
            // olvColumn27
            // 
            this.olvColumn27.AspectName = "Variant";
            this.olvColumn27.CellPadding = null;
            this.olvColumn27.Text = "Variant Fulfillment Service";
            // 
            // olvColumn28
            // 
            this.olvColumn28.AspectName = "Gia";
            this.olvColumn28.CellPadding = null;
            this.olvColumn28.Text = "Giá";
            // 
            // olvColumn29
            // 
            this.olvColumn29.AspectName = "GiaSoSanh";
            this.olvColumn29.CellPadding = null;
            this.olvColumn29.Text = "Giá so sánh";
            // 
            // olvColumn30
            // 
            this.olvColumn30.AspectName = "YeuCauVanChuyen";
            this.olvColumn30.CellPadding = null;
            this.olvColumn30.Text = "Yêu cầu vận chuyển";
            // 
            // olvColumn31
            // 
            this.olvColumn31.AspectName = "VAT";
            this.olvColumn31.CellPadding = null;
            this.olvColumn31.Text = "VAT";
            // 
            // olvColumn32
            // 
            this.olvColumn32.AspectName = "MaVach";
            this.olvColumn32.CellPadding = null;
            this.olvColumn32.Text = "Mã vạch(Barcode)";
            // 
            // olvColumn33
            // 
            this.olvColumn33.AspectName = "AnhDaiDien";
            this.olvColumn33.CellPadding = null;
            this.olvColumn33.Text = "Ảnh đại diện";
            // 
            // olvColumn34
            // 
            this.olvColumn34.AspectName = "ChuThich";
            this.olvColumn34.CellPadding = null;
            this.olvColumn34.Text = "Chú thích ảnh";
            // 
            // olvColumn35
            // 
            this.olvColumn35.AspectName = "TheTieuDe";
            this.olvColumn35.CellPadding = null;
            this.olvColumn35.Text = "Thẻ tiêu đề(SEO Title)";
            // 
            // olvColumn36
            // 
            this.olvColumn36.AspectName = "TheMoTa";
            this.olvColumn36.CellPadding = null;
            this.olvColumn36.Text = "Thẻ mô tả(SEO Description)";
            // 
            // olvColumn37
            // 
            this.olvColumn37.AspectName = "CanNang";
            this.olvColumn37.CellPadding = null;
            this.olvColumn37.Text = "Cân nặng";
            // 
            // olvColumn38
            // 
            this.olvColumn38.AspectName = "DonViCan";
            this.olvColumn38.CellPadding = null;
            this.olvColumn38.Text = "Đơn vị cân nặng";
            // 
            // olvColumn39
            // 
            this.olvColumn39.AspectName = "AnhPhienBan";
            this.olvColumn39.CellPadding = null;
            this.olvColumn39.Text = "Ảnh phiên bản";
            // 
            // olvColumn40
            // 
            this.olvColumn40.AspectName = "MoTaNgan";
            this.olvColumn40.CellPadding = null;
            this.olvColumn40.Text = "Mô tả ngắn";
            // 
            // olvColumn41
            // 
            this.olvColumn41.AspectName = "ID";
            this.olvColumn41.CellPadding = null;
            this.olvColumn41.Text = "Id sản phẩm";
            // 
            // olvColumn42
            // 
            this.olvColumn42.AspectName = "IDTuyChon";
            this.olvColumn42.CellPadding = null;
            this.olvColumn42.Text = "Id tùy chọn";
            // 
            // TimerSearch
            // 
            this.TimerSearch.Tick += new System.EventHandler(this.TimerSearch_Tick);
            // 
            // FormViewSanPhamWeb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1736, 819);
            this.Controls.Add(this.panelEx1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormViewSanPhamWeb";
            this.Text = "Danh Sách Sản Phẩm Web";
            this.Load += new System.EventHandler(this.Database_Load);
            this.panelEx1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mListViewData)).EndInit();
            this.panelEx3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DichVuMenuBar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.Controls.TextBoxX txtSearch;
        private DevComponents.DotNetBar.LabelItem labelItem2;
        private DevComponents.DotNetBar.ButtonItem btnXoa;
        private DevComponents.DotNetBar.Controls.CircularProgress DataProgress;
        private Sanita.Utility.UI.ObjectListView mListViewData;
        private Sanita.Utility.UI.OLVColumn olvColumn2;
        private Sanita.Utility.UI.OLVColumn olvColumn4;
        private Sanita.Utility.UI.OLVColumn olvColumn1;
        private Sanita.Utility.UI.OLVColumn olvColumn3;
        private DevComponents.DotNetBar.ControlContainerItem controlContainerItem1;
        private Sanita.Utility.UI.OLVColumn olvColumn6;
        private Sanita.Utility.UI.OLVColumn olvColumn7;
        private Sanita.Utility.UI.OLVColumn olvColumn8;
        private Sanita.Utility.UI.OLVColumn olvColumn9;
        private Sanita.Utility.UI.OLVColumn olvColumn10;
        private DevComponents.DotNetBar.PanelEx panelEx3;
        private DevComponents.DotNetBar.ButtonX btnAdd;
        private DevComponents.DotNetBar.ButtonX btnRefresh;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.LabelItem labelItem1;
        private DevComponents.DotNetBar.ButtonItem btnImport;
        private DevComponents.DotNetBar.ButtonItem btnExport;
        private DevComponents.DotNetBar.ButtonItem btnExit;
        private DevComponents.DotNetBar.LabelX lblBenhAn;
        private DevComponents.DotNetBar.ButtonItem DichVuMenu;
        private DevComponents.DotNetBar.ContextMenuBar DichVuMenuBar;
        private Sanita.Utility.UI.OLVColumn olvColumn5;
        private Sanita.Utility.UI.OLVColumn olvColumn11;
        private Sanita.Utility.UI.OLVColumn olvColumn12;
        private Sanita.Utility.UI.OLVColumn olvColumn13;
        private Sanita.Utility.UI.OLVColumn olvColumn14;
        private Sanita.Utility.UI.OLVColumn olvColumn15;
        private Sanita.Utility.UI.OLVColumn olvColumn16;
        private Sanita.Utility.UI.OLVColumn olvColumn17;
        private Sanita.Utility.UI.OLVColumn olvColumn18;
        private Sanita.Utility.UI.OLVColumn olvColumn19;
        private Sanita.Utility.UI.OLVColumn olvColumn20;
        private Sanita.Utility.UI.OLVColumn olvColumn21;
        private Sanita.Utility.UI.OLVColumn olvColumn22;
        private Sanita.Utility.UI.OLVColumn olvColumn23;
        private Sanita.Utility.UI.OLVColumn olvColumn24;
        private Sanita.Utility.UI.OLVColumn olvColumn25;
        private Sanita.Utility.UI.OLVColumn olvColumn26;
        private Sanita.Utility.UI.OLVColumn olvColumn27;
        private Sanita.Utility.UI.OLVColumn olvColumn28;
        private Sanita.Utility.UI.OLVColumn olvColumn29;
        private Sanita.Utility.UI.OLVColumn olvColumn30;
        private Sanita.Utility.UI.OLVColumn olvColumn31;
        private Sanita.Utility.UI.OLVColumn olvColumn32;
        private Sanita.Utility.UI.OLVColumn olvColumn33;
        private Sanita.Utility.UI.OLVColumn olvColumn34;
        private Sanita.Utility.UI.OLVColumn olvColumn35;
        private Sanita.Utility.UI.OLVColumn olvColumn36;
        private Sanita.Utility.UI.OLVColumn olvColumn37;
        private Sanita.Utility.UI.OLVColumn olvColumn38;
        private Sanita.Utility.UI.OLVColumn olvColumn39;
        private Sanita.Utility.UI.OLVColumn olvColumn40;
        private Sanita.Utility.UI.OLVColumn olvColumn41;
        private Sanita.Utility.UI.OLVColumn olvColumn42;
        private System.Windows.Forms.Timer TimerSearch;
    }
}