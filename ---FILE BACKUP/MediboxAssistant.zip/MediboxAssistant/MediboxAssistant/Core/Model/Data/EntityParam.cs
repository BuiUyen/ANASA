﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Medibox.Model
{
    [Serializable()]
    public class EntityParam
    {
        public String Name { get; set; }
        public String Value { get; set; }
    }
}
