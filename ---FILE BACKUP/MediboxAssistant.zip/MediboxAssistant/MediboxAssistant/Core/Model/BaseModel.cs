﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Medibox.Model
{
    [Serializable()]
    public class BaseModel
    {

    }
}
