﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Medibox.Model
{
    public class DataTypeModel
    {
        public const int RESULT_NG = -100;          //Common DB error
        public const int RESULT_OK = 1;             //DB ok
    }
}
